#include <QApplication>
#include <QMainWindow>
#include <QLabel>
#include <QPushButton>
#include <QLineEdit>
#include <QSlider>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QColorDialog>
#include <QFileDialog>
#include <QPainter>
#include <QMouseEvent>
#include <QImage>
#include <QMessageBox>

class MainWindow : public QMainWindow {
public:
    MainWindow(QWidget *parent = nullptr) : QMainWindow(parent),
        textColor(Qt::black), textSize(20), textThickness(1), textPosition(50,50), dragging(false)
    {
        QWidget *central = new QWidget;
        setCentralWidget(central);

        // Widgeturi
        labelImage = new QLabel;
        labelImage->setFixedSize(600, 400);
        labelImage->setStyleSheet("QLabel { background-color : lightgray; }");
        labelImage->setScaledContents(true);

        lineEditText = new QLineEdit;

        sliderSize = new QSlider(Qt::Horizontal);
        sliderSize->setRange(10, 100);
        sliderSize->setValue(textSize);

        sliderThickness = new QSlider(Qt::Horizontal);
        sliderThickness->setRange(1, 10);
        sliderThickness->setValue(textThickness);

        btnLoad = new QPushButton("Load Image");
        btnSave = new QPushButton("Save Image");
        btnColor = new QPushButton("Choose Color");

        // Layouturi
        QVBoxLayout *mainLayout = new QVBoxLayout;
        mainLayout->addWidget(labelImage);
        mainLayout->addWidget(lineEditText);

        QHBoxLayout *sliderLayout = new QHBoxLayout;
        sliderLayout->addWidget(sliderSize);
        sliderLayout->addWidget(sliderThickness);
        mainLayout->addLayout(sliderLayout);

        QHBoxLayout *buttonLayout = new QHBoxLayout;
        buttonLayout->addWidget(btnLoad);
        buttonLayout->addWidget(btnSave);
        buttonLayout->addWidget(btnColor);
        mainLayout->addLayout(buttonLayout);

        central->setLayout(mainLayout);

        // Conexiuni
        QObject::connect(btnLoad, &QPushButton::clicked, [this](){ loadImage(); });
        QObject::connect(btnSave, &QPushButton::clicked, [this](){ saveImage(); });
        QObject::connect(lineEditText, &QLineEdit::textChanged, [this](){ redrawImage(); });
        QObject::connect(sliderSize, &QSlider::valueChanged, [this](int val){ textSize = val; redrawImage(); });
        QObject::connect(sliderThickness, &QSlider::valueChanged, [this](int val){ textThickness = val; redrawImage(); });
        QObject::connect(btnColor, &QPushButton::clicked, [this](){ chooseColor(); });

        // Încarcă automat o imagine
        QString defaultPath = "C:/Users/deaco/OneDrive/Desktop/C++Projects/TemaLab3/rama.jpeg";
        if(!image.load(defaultPath)) {
            QMessageBox::warning(this, "Error", "Could not load initial image!");
        } else {
            displayedImage = image;
            redrawImage();
        }
    }

protected:
    void mousePressEvent(QMouseEvent *event) override {
        if(!image.isNull() && labelImage->geometry().contains(event->pos())) {
            dragging = true;
            dragOffset = event->pos() - labelImage->pos() - textPosition;
        }
    }

    void mouseMoveEvent(QMouseEvent *event) override {
        if(dragging && !image.isNull()) {
            textPosition = event->pos() - labelImage->pos() - dragOffset;
            redrawImage();
        }
    }

    void mouseReleaseEvent(QMouseEvent *) override {
        dragging = false;
    }

private:
    QLabel *labelImage;
    QPushButton *btnLoad, *btnSave, *btnColor;
    QLineEdit *lineEditText;
    QSlider *sliderSize, *sliderThickness;

    QImage image;
    QImage displayedImage;
    QPoint textPosition;
    QColor textColor;
    int textSize;
    int textThickness;
    bool dragging;
    QPoint dragOffset;

    void loadImage() {
        QString fileName = QFileDialog::getOpenFileName(this, "Load Image", "", "Images (*.png *.jpg *.bmp)");
        if(fileName.isEmpty()) return;
        if(!image.load(fileName)) {
            QMessageBox::warning(this, "Error", "Could not load image!");
            return;
        }
        displayedImage = image;
        redrawImage();
    }

    void saveImage() {
        QString fileName = QFileDialog::getSaveFileName(this, "Save Image", "", "PNG (*.png);;JPG (*.jpg)");
        if(fileName.isEmpty()) return;
        if(!displayedImage.save(fileName)) {
            QMessageBox::warning(this, "Error", "Could not save image!");
        }
    }

    void chooseColor() {
        QColor color = QColorDialog::getColor(textColor, this, "Select Text Color");
        if(color.isValid()) {
            textColor = color;
            redrawImage();
        }
    }

    void redrawImage() {
        if(image.isNull()) return;
        displayedImage = image.copy();

        QPainter painter(&displayedImage);
        QPen pen(textColor);
        painter.setPen(pen);

        // controlează grosimea textului prin "weight" (100–900)
        QFont font = painter.font();
        font.setPointSize(textSize);
        int weightValue = 100 + textThickness * 80;
        if (weightValue > QFont::Black) weightValue = QFont::Black;
        font.setWeight(static_cast<QFont::Weight>(weightValue));
        painter.setFont(font);

        painter.drawText(textPosition, lineEditText->text());

        labelImage->setPixmap(QPixmap::fromImage(displayedImage));
    }
};

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    MainWindow w;
    w.show();
    return a.exec();
}
