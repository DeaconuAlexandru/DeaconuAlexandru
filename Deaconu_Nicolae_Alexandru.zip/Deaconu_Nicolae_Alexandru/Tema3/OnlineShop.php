<?php
// Am setat hostname-ul meu MySQL
$hostname = 'localhost';

// Am setat username-ul meu MySQL
$username = 'Alex';

// Am setat parola mea MySQL
$password = 'alexstudent';

// Numele fișierului XML care contine datele ce urmeaza sa fie inserate în baza de date
$xmlFile = 'CumparaturiOnline.xml';

try {
    // Am conectat la baza de date folosind PDO (PHP Data Objects)
    $dbh = new PDO("mysql:host=$hostname;dbname=tema3", $username, $password);
    // Se seteaza modul de raportare a erorilor la PDOException
    $dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Se parseaza fișierul XML si se incarca intr-un obiect SimpleXMLElement
    $xml = simplexml_load_file($xmlFile);

    // Se extrag datele comenzii din fișierul XML
    $comandaID = $xml->id;
    $data = $xml->data;
    $numeClient = $xml->client->nume;
    $adresaClient = $xml->client->adresa;
    $emailClient = $xml->client->email;
    $total = $xml->total;
    $metodaPlata = $xml->metoda_plata;
    $status = $xml->status;

    // Am pregatit instrucțiunea SQL pentru inserarea datelor în tabela OnlineShop
    $stmt = $dbh->prepare("INSERT INTO OnlineShop (Nume, Pret, Descriere) VALUES (:nume, :pret, :descriere)");

    // Parcurge fiecare produs din sectiunea "produse" a fișierului XML și insereaza datele în baza de date
    foreach ($xml->produse->produs as $produs) {
        // Extrage detaliile fiecărui produs
        $numeProdus = $produs->nume;
        $cantitateProdus = $produs->cantitate;
        $pretProdus = $produs->pret;
        $descriereProdus = "Descriere produs"; // Am setat o descriere fixa pentru fiecare produs, aceasta poate fi personalizata

        // Am legat valorile extrase de parametrii instrucțiunii SQL
        $stmt->bindParam(':nume', $numeProdus);
        $stmt->bindParam(':pret', $pretProdus);
        $stmt->bindParam(':descriere', $descriereProdus);

        // Se executa instrucțiunea SQL pentru a insera datele în baza de date
        $stmt->execute();
    }

    // Se afiseaza un mesaj de succes
    echo 'Datele au fost inserate cu succes în baza de date.';

} catch(PDOException $e) {
    // În caz de eroare, afișează mesajul de eroare
    echo 'A apărut o eroare: ' . $e->getMessage();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Online Shop</title>
    <style>
        /* Stiluri pentru pagina HTML */
        body {
            background-color: #000;
            color: #fff;
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
        }

        .container {
            width: 80%;
            margin: 0 auto;
            text-align: center;
            padding-top: 50px;
        }

        h1 {
            font-size: 3em;
            margin-bottom: 20px;
        }

        p {
            font-size: 1.2em;
            line-height: 1.5;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Magazinul Online</h1>
        <p>Bun venit în magazinul nostru online! Mai jos sunt detaliile ultimei comenzi:</p>
        <!-- Se afiseaza detaliile comenzii extrase din fișierul XML -->
        <p>ID Comandă: <?php echo $comandaID; ?></p>
        <p>Data: <?php echo $data; ?></p>
        <p>Nume Client: <?php echo $numeClient; ?></p>
        <p>Adresă Client: <?php echo $adresaClient; ?></p>
        <p>Email Client: <?php echo $emailClient; ?></p>
        <p>Total: <?php echo $total; ?></p>
        <p>Metodă de plată: <?php echo $metodaPlata; ?></p>
        <p>Status: <?php echo $status; ?></p>
    </div>
</body>
</html>
