-- Creeaz? baza de date
CREATE DATABASE IF NOT EXISTS tema3;

-- Folose?te baza de date creat?
USE tema3;

-- Creeaz? tabela 'onlineshop'
CREATE TABLE IF NOT EXISTS echipe (
    ProdusID INT(11) AUTO_INCREMENT PRIMARY KEY,
	nume TEXT,
    pret DECIMAL(10, 2),
    descriere TEXT
);