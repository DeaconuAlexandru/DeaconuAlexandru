<?php
session_start();

/*** mysql hostname ***/
$hostname = 'localhost';

/*** mysql username ***/
$username = 'Alex';

/*** mysql password ***/
$password = 'alexstudent';

try {
    $dbh = new PDO("mysql:host=$hostname;dbname=tema2", $username, $password);
    /*** echo a message saying we have connected ***/
    echo 'Connected to database';
}
catch(PDOException $e)
{
    echo $e->getMessage();
    exit; // Am iesit din script în caz de eroare la conectare
}

//Am distrus sesiunea când utilizatorul se deconectează
session_destroy();

header("location: Home.php"); // Se redirectioneaza catre pagina de Home
exit;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Logout</title>
</head>
<body>

<h2>Deconectare reușită</h2>
<p>Ați fost deconectat cu succes.</p>
</body>
</html>
