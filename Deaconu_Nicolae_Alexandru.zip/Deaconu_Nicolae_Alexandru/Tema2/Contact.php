<?php
/*** mysql hostname ***/
$hostname = 'localhost';

/*** mysql username ***/
$username = 'Alex';

/*** mysql password ***/
$password = 'alexstudent';

try {
    $dbh = new PDO("mysql:host=$hostname;dbname=tema2", $username, $password);
    /*** echo a message saying we have connected ***/
    echo 'Connected to database';
}
catch(PDOException $e)
{
    echo $e->getMessage();
}
?>
<!DOCTYPE html>
<html lang="ro">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact - Clubul Sportiv al lui Alex</title>
    <style>
        body {
            background-color: black;
            color: skyblue;
            font-family: Arial, sans-serif;
            padding: 20px;
        }

        h1 {
            text-align: center;
        }

        .contact-info {
            margin-top: 30px;
        }

        .contact-info h2 {
            color: pink;
            font-size: 20px;
            margin-bottom: 10px;
        }

        .contact-info ul {
            list-style-type: none;
            padding-left: 0;
        }

        .contact-info li {
            margin-bottom: 10px;
        }

        .contact-info li strong {
            color: pink;
        }
    </style>
</head>

<body>
<div class="navbar">
    <a href="Home.php">Acasă</a>
    <a href="Sectii.php">Sectii</a>
    <a href="Galerie.php">Galerie</a>
    <a href="Contact.php">Contact</a>
    <a href="Anunturi.php">Anunțuri</a>
    <a href="Echipe.php">Echipe</a>
    <h1>Contact - Clubul Sportiv al lui Alex</h1>

    <div class="contact-info">
        <h2>Contactați-l pe Alex:</h2>
        <ul>
            <li><strong>Email:</strong> alexboss@gmail.com</li>
            <li><strong>Facebook:</strong> Alex Barosanu</li>
            <li><strong>Instagram:</strong> Alex</li>
            <li><strong>Nr de telefon al lui Alex:</strong> 0770249012</li>
        </ul>
    </div>

    <div class="contact-info">
        <h2>Detaliile clubului:</h2>
        <ul>
            <li><strong>Emailul clubului:</strong> club@gmail.ro</li>
            <li><strong>Nr de telefon al clubului:</strong> 0754426391</li>
        </ul>
    </div>
</body>

</html>
