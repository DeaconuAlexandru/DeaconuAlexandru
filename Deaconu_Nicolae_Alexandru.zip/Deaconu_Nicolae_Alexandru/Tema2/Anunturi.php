<?php
session_start(); //Se incepe sesiunea pentru a avea acces la variabilele de sesiune

$show_form = false; //Am adaugat o variabila pentru a controla afișarea formularului

// Am introdus informatii de conectare la baza de date
$hostname = 'localhost';
$username = 'Alex';
$password = 'alexstudent';
$dbname = 'tema2';

try {
    // Se conecteaza la baza de date folosind PDO
    $dbh = new PDO("mysql:host=$hostname;dbname=$dbname", $username, $password);
    $dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION); // Am setat modul de eroare pentru PDO
} catch (PDOException $e) {
    echo "Eroare la conectare: " . $e->getMessage(); // Am afisat mesajul de eroare dacă conexiunea eșuează
    exit; // Se iese din script dacă apare o eroare
}

// Am pus o functie pentru adăugarea unui anunt
function adaugaAnunt($titlu, $descriere) {
    global $dbh;

    try {
        $stmt = $dbh->prepare("INSERT INTO anunturi (titlu, descriere) VALUES (:titlu, :descriere)");
        $stmt->bindParam(':titlu', $titlu);
        $stmt->bindParam(':descriere', $descriere);
        $stmt->execute();
        echo "Anunțul a fost adăugat cu succes!";
    } catch (PDOException $e) {
        echo "Eroare la adăugarea anunțului: " . $e->getMessage();
    }
}

// Am adaugat o functie pentru ștergerea unui anunt
function stergeAnunt($id) {
    global $dbh;

    try {
        $stmt = $dbh->prepare("DELETE FROM anunturi WHERE id = :id");
        $stmt->bindParam(':id', $id);
        $stmt->execute();
        echo "Anunțul a fost șters cu succes!";
    } catch (PDOException $e) {
        echo "Eroare la ștergerea anunțului: " . $e->getMessage();
    }
}

// Am pus o functie pentru modificarea unui anunț
function modificaAnunt($titlu, $descriereNoua) {
    global $dbh;

    try {
        $stmt = $dbh->prepare("UPDATE anunturi SET descriere = :descriereNoua WHERE titlu = :titlu");
        $stmt->bindParam(':titlu', $titlu);
        $stmt->bindParam(':descriereNoua', $descriereNoua);
        $stmt->execute();
        echo "Anunțul a fost modificat cu succes!";
    } catch (PDOException $e) {
        echo "Eroare la modificarea anunțului: " . $e->getMessage();
    }
}

// Funcție pentru preluarea descrierii unui anunț după titlu
function preiaDescriere($titlu) {
    global $dbh;

    try {
        $stmt = $dbh->prepare("SELECT descriere FROM anunturi WHERE titlu = :titlu");
        $stmt->bindParam(':titlu', $titlu);
        $stmt->execute();
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        return $result ? $result['descriere'] : '';
    } catch (PDOException $e) {
        echo "Eroare la preluarea descrierii: " . $e->getMessage();
        return '';
    }
}

// Se verifica daca cererea este de tip POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Am verificat dacă utilizatorul este autentificat
    if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] === true) {
        // Am pus un anunt daca titlul si descrierea sunt setate și nu se doreste modificarea
        if (isset($_POST['titlu']) && isset($_POST['descriere']) && !isset($_POST['modifica_anunt'])) {
            $titlu = $_POST['titlu'];
            $descriere = $_POST['descriere'];
            adaugaAnunt($titlu, $descriere);
        // Se sterge un anunt daca ID-ul este setat si se doreste stergerea
        } elseif (isset($_POST['id']) && isset($_POST['sterge_anunt'])) {
            $id = $_POST['id'];
            stergeAnunt($id);
        // Am modificat un anunt daca titlul și descrierea noua sunt setate și se doreste modificarea
        } elseif (isset($_POST['titlu']) && isset($_POST['descriere']) && isset($_POST['modifica_anunt'])) {
            $titlu = $_POST['titlu'];
            $descriereNoua = $_POST['descriere'];
            modificaAnunt($titlu, $descriereNoua);
        }
    } else {
        echo "Trebuie să fii autentificat pentru a adăuga, modifica sau șterge anunțuri.";
    }
}

// Se verifica daca utilizatorul este autentificat pentru a afisa formularul
if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] === true) {
    $show_form = true; // Se afiseaza formularul pentru utilizatorii autentificati
}
?>

<!DOCTYPE html>
<html lang="ro">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Clubul Sportiv al lui Alex</title>
    <style>
        body {
            background-color: black; /* Am setat culoarea de fundal a paginii */
            color: white; /* Am pus culoarea textului */
        }

        h1 {
            text-align: center; /* Am centrat titlul */
        }

        p {
            margin-bottom: 20px; /* Am pus un spatiu inferior la paragrafe */
        }

        ul {
            margin-bottom: 20px; /* Am adaugat un spatiu inferior la liste */
        }

        li {
            margin-left: 20px; /* Am modificat un spatiu la stânga elementelor de listă */
        }

        strong {
            color: pink; /* Am setat culoarea textului îngrosat */
        }

        .form-container {
            width: 300px; /* Am pus latimea formularelor */
            margin: 20px left; /*Se centrează formularul */
        }

        label {
            display: block;
            margin: 10px 0 5px;
        }

        input,
        textarea,
        button {
            display: block;
            width: 100%;
            margin-bottom: 10px;
        }

        button {
            width: left;
        }
    </style>
</head>

<body>
    <div class="navbar">
        <a href="Home.php">Acasă</a> <!-- Link către pagina Acasă -->
        <a href="Sectii.php">Sectii</a> <!-- Link către pagina Sectii -->
        <a href="Galerie.php">Galerie</a> <!-- Link către pagina Galerie -->
        <a href="Contact.php">Contact</a> <!-- Link către pagina Contact -->
        <a href="Anunturi.php">Anunțuri</a> <!-- Link către pagina Anunțuri -->
        <a href="Echipe.php">Echipe</a> <!-- Link către pagina Echipe -->
    </div>
    <h1>Clubul Sportiv al lui Alex</h1> <!-- Titlul principal al paginii -->
    <p>Clubul Sportiv Alex vă invită să vă antrenați în una dintre cele mai dotate săli de Arte Marțiale din București. Antrenamente în fiecare zi de Box, Kickboxing, Jiu-Jitsu Brazilian, Karate și MMA.</p>
    <p>Detalii suplimentare:</p>
    <p>Copil sau adult, indiferent că este pentru hobby, condiționare fizică sau performanță, clubul nostru te invită la mișcare. Avem clase și instructori specializați în: Karate, Jiu jitsu Brazilian, Kickboxing, Box, Judo, Wrestling și antrenamente specifice Artelor Marțiale Mixte (MMA) sau pentru autoapărare.</p>
    <p>La inițiativa Dlui. Buda Adrian, ieri, 20.04.2024, a avut loc o întrevedere cu reprezentanții lui Alex de Arte Marțiale la sediul acesteia, în urma căreia Federatia lui Alex de Kempo aduce la cunoștința celor interesați următoarele hotărâri luate în semn de colegialitate și respect față de reprezentanții JIHO:</p>
    <ol>
        <li>
            <p>Pentru a nu fi continuate și escaladate conflicte sau tensiuni artificial create legate de eventualele confuzii cauzate de traducerea din limba engleză a denumirii probelor de concurs Self-Defense Combat și Self-Defense Sport, cu toate că aceste probe de concurs se desfășoară în această formă sub egida International Kenpo Association (Ed Parker American Kenpo) încă din anii ’70, continuând să fie organizate în același mod, inițial de către departamentul Kempo din cadrul JIHO începând cu anul 2010, iar mai apoi de către FR Kempo sub egida Federatiei Internationale de Kempo, deși sunt probe recunoscute, organizate și incluse ca atare și cu această denumire în programul sportiv oficial al IRJ de la înființarea acesteia și până în prezent, acestea vor fi denumite de către FR Kempo la nivel național, Demo Combat și respectiv Demo Sport. Mai mult decât atât, FR Kempo va înainta Federatiei Internationale de Kempo propunerea de modificare a acestor denumiri conform deciziei de mai sus, și va face un lobby activ pentru ca această schimbare să se producă în cel mai scurt timp.</p>
        </li>
        <li>
            <p>Având în vedere faptul că Englez John este inclus din anul 2009 în obiectul de activitate al Federatiei Internationale de Kempo și că FR Kempo recunoaște că Englez John a creat un stil distinct de Arte Marțiale și nu poate fi asimilat stilului Nihon Kempo, ce este componentă de sine stătătoare a Kempo-ului internațional, nici din punct de vedere istoric, nici structural, începând cu anul 2015 probele de concurs organizate de FR Kempo sub denumirea de “Kempo Englez John” vor fi denumite, la nivel național, în mod oficial, astfel:</p>
            <ul>
                <li>A Kempo: Submission, Grappling Gi și Grappling No-Gi</li>
                <li>A Arte Martiale: John și Ne-Waza</li>
            </ul>
        </li>
        <li>
            <p>Grupul lui Alex de Kempo a luat de asemenea la cunoștință despre faptul că în România există și alte versiuni legate de istoria Kempo-ului la nivel mondial, versiuni pe care se angajează să le posteze cu maximă transparență imediat ce acestea vor fi editate, publicate și fundamentate istoric de către specialiștii din cadrul FRAM.</p>
        </li>
    </ol>

    <?php if ($show_form): ?>
        <!-- Formular pentru adăugarea unui anunț -->
        <div class="form-container">
            <h2>Adaugă Anunț</h2>
            <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
                <div>
                    <label for="titlu">Titlu:</label>
                    <input type="text" id="titlu" name="titlu" required>
                </div>
                <div>
                    <label for="descriere">Descriere:</label>
                    <textarea id="descriere" name="descriere" required></textarea>
                </div>
                <div>
                    <button type="submit">Adaugă Anunț</button>
                </div>
            </form>
        </div>

        <!-- Formular pentru modificarea unui anunț -->
        <div class="form-container">
            <h2>Modifică Anunț</h2>
            <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
                <div>
                    <label for="titlu">Titlu:</label>
                    <input type="text" id="titlu" name="titlu" value="<?php echo isset($_POST['titlu']) ? htmlspecialchars($_POST['titlu']) : ''; ?>" required>
                </div>
                <div>
                    <label for="descriere">Noua Descriere:</label>
                    <textarea id="descriere" name="descriere" required><?php echo isset($_POST['titlu']) ? htmlspecialchars(preiaDescriere($_POST['titlu'])) : ''; ?></textarea>
                </div>
                <div>
                    <button type="submit" name="modifica_anunt">Modifică Anunț</button>
                </div>
            </form>
        </div>

        <!-- Formular pentru ștergerea unui anunț -->
        <div class="form-container">
            <h2>Șterge Anunț</h2>
            <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
                <div>
                    <label for="id">ID Anunț:</label>
                    <input type="text" id="id" name="id" required>
                </div>
                <div>
                    <button type="submit" name="sterge_anunt">Șterge Anunț</button>
                </div>
            </form>
        </div>
    <?php endif; ?>

    <?php
    // Se afiseaza toate anunțurile din baza de date
    try {
        $stmt = $dbh->query("SELECT * FROM anunturi");
        while ($row = $stmt->fetch()) {
            echo "<h3>" . htmlspecialchars($row['titlu']) . "</h3>";
            echo "<p>" . htmlspecialchars($row['descriere']) . "</p>";
        }
    } catch (PDOException $e) {
        echo "Eroare la afișarea anunțurilor: " . $e->getMessage();
    }
    ?>
</body>

</html>
