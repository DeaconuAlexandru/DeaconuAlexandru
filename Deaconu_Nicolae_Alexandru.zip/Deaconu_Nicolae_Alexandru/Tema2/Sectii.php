<?php
/*** mysql hostname ***/
$hostname = 'localhost';

/*** mysql username ***/
$username = 'Alex';

/*** mysql password ***/
$password = 'alexstudent';

try {
    $dbh = new PDO("mysql:host=$hostname;dbname=tema2", $username, $password);
    /*** echo a message saying we have connected ***/
    echo 'Connected to database';
}
catch(PDOException $e)
{
    echo $e->getMessage();
}
?>
<!DOCTYPE html>
<html lang="ro">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Clubul De Sport al lui Alex</title>
    <style>
        body {
            background-color: black;
            color: mediumpurple;
        }
    </style>
</head>
    <div class="navbar">
    <a href="Home.php">Acasă</a>
    <a href="Sectii.php">Sectii</a>
    <a href="Galerie.php">Galerie</a>
    <a href="Contact.php">Contact</a>
    <a href="Anunturi.php">Anunțuri</a>
    <a href="Echipe.php">Echipe</a>
</div>
    <h1>Clubul De Sport al lui Alex</h1>
    <p>Clubul De Sport al lui Alex promovează activități din următoarele categorii:</p>
    <ul>
        <li>Aerobic</li>
        <li>Fitness</li>
        <li>Fotbal</li>
        <li>Arte marțiale</li>
        <li>Inot</li>
        <li>Tenis de camp</li>
        <li>Dans</li>
        <li>Box</li>
        <li>Atletism</li>
        <li>Baschet</li>
        <li>Pescuit</li>
        <li>Schi</li>
        <li>Sporturi extreme</li>
        <li>Biliard</li>
        <li>Echitație</li>
        <li>Sah</li>
        <li>Tenis de masă</li>
        <li>Ciclism</li>
        <li>Sporturi diverse</li>
        <li>Rugby</li>
        <li>Volei</li>
        <li>Tennis</li>
        <li>Handbal</li>
        <li>Scrima</li>
    </ul>
    <p>Pentru informații despre servicii și contact, vă rugăm să contactați:</p>
    <p><strong>Club De Sport</strong></p>
    <p><strong>Club De Sport Club De Sport promoveaza afaceri din categoriile Aerobic Fitness Fotbal Arte martiale Inot Tenis de camp Dans Box Atletism Baschet Pescuit Schi Sporturi extreme Biliard Echitatie Sah Tenis de masa Ciclism Sporturi diverse Rugby Volei Tennis Handbal Scrima servicii de calitate - contact acum: Club De Sport, Aerobic, gimnastica aerobica, antrenament aerobic, exercitii tonifiere, program aerobic, brate, coapse, cardio kangoo jumps, smart streching, fitball training, abonamente aerobic, Fitness, club fitness, cursuri aerobic fitness, instructor fitness, aerobic dance, sali de fitness, bodybuilding, kangoo jumps, cardio, fitball, salai de forta, ridicare greutati, culturism, Fotbal, club de fotbal, scoala de fotbal, academii de fotbal, inscrieri fotbal juniori, cursuri fotbal copii, performanta si initiere in fotbal, antrenamente fotbal, dribling,, Arte martiale, club sportiv arte martiale, antrenamente arte martiale, judo, yoga, karate, wushu, box tailandez, kickbox chinezesc, aikido, jiu-jitsu, arte martiale mixte, mma, Inot, club sportiv inot, cursuri inot, bazin sportiv de inot, inot de agrement, inot pentru bebelusi, lectii de inot, cursuri inot adulti, Tenis de camp, club tenis, antrenor tenis de camp, cursuri tenis de camp, tenis de performanta, tenis copii, tenis zgura, tenis iarba, Dans, club de dans, cursuri de dans, scoala de dans, cursuri de dans pentru copii, curs vals, scoala de dans, curs balet, dans sportiv, dans de salon, samba, dansul mirilor, zumba dance, aerobic dance, dans modern, Box, club de box, cursuri box, antrenamente box, sala de box, asociatii sportive de box, antrenor personal de box, pregatire fizica sporturi de contact kick-box mma, sedinte antrenament box, Atletism, club sportiv atletism, metode alergare, stafeta, maraton, alegare pe distante lungi, activitati fizice, prevenire obezitate, sport olimpic, sprinturi, sarituri, aruncari, Baschet, club sportiv baschet, cursuri baschet, alergari, driblari, sarituri, pozitii jucatori, panou baschet, regulament baschet, Pescuit, club de pescuit, pescuit sportiv, pescuit la crap, pescuit caras, ten si somn, pescuit de competitie, concurs pescuit, Schi, club de schi, scoala de schi, cursuri schi pentru copii, schi alpin, cursuri schi adulti, tabara ski, cursuri ski, instructor ski, Sporturi extreme, club sporturi extreme, saritura cu coarda elastica, sarituri cu schiurile, parasutism, sky flying, surf aerian, base jumping, sporturi aeriene, sporturi terestre, ciclism montan, patinaj extrem cu role, schi nautic, sarituri in apa de pe stanci, surfing, scufundari sub gheata, deltaplanorism, Biliard, scoala de biliard, cursuri biliard, pozitia la masa de biliard, priza pe tac, priza pe masa de biliard, lovitura cu manta, lectii de biliard, antrenor biliard, lovituri cu stop, lovitura cu retur, masse, Echitatie, club de echitatie, echitatie incepatori, echitatie avansati, echitatie in aer liber, echitatie in parc, echitatie in menej, centre de echitatie, cursuri calarie, scoli de echitatie, sedinte de echitatie, calarie de agrement, trap si initiere galop la coarda, pas si trap liber in manej, exercitii la cavalete, Sah, club de sah, academii de sah, cursuri de sah, concursuri de sah, scoala de sah juniori, Tenis de masa, club tenis de masa, antrenor tenis de masa, cursuri tenis de masa, tenis de performanta, scoala ping-pong, cursuri copii tenis de masa, Ciclism, club ciclism, cursuri ciclism, ciclism competitiv si triatlon, ciclism de sosea, ciclo-cros, velodrom, cursuri mountain-bike, cursuri MTB, initiere bicicleta copii, bike trial, Sporturi diverse, cluburi sporturi diverse, activitati sportive pentru copii, aruncarea cu discul, aruncarea greutatii, sarituri in lungime, hochei, patinaj, karting, darts, Rugby, club de rugby, scoala de rugby, echipe de rugby, antrenament rugby, rugby copii si juniori, Volei, club de volei, antrenor volei, cursuri volei, volei de performanta, scoala de volei, cursuri copii volei, curs volei feminin,volei masculin, Tennis, academie tenis, club tennis, cursuri tennis, tennis copii, tennis de performanta, scoala tennis, sedinte tennis, tenis zgura, tenis pe iarba, cursuri tennis copii si adulti, tennis, tenis, tenis de camp, minge, backspin, baseline, block, joc de tennis, joc de tenis, cursuri tenis, competitie tenis,tennis iarba, tennis zgura, Handbal, club handbal, cursuri handbal, inscrieri handbal, handbal copii, handbalist, cursuri de sport handbal, handbal juniori, handbal de performanta, echipe handbal, Scrima, club scrima, cursuri scrima copii, performanta la scrima, scrima adulti, pret cursuri scrima, inscriere club scrima, lecti scrima, antrenor scrima, echipament scrima, antrenament scrima, scrima fete, scrima baieti,</strong></p>
</body>
</html>
