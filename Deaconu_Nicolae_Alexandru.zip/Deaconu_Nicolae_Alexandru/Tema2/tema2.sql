-- Creeaz? baza de date
CREATE DATABASE IF NOT EXISTS tema2;

-- Folose?te baza de date creat?
USE tema2;

CREATE TABLE users (
    id INT(11) AUTO_INCREMENT PRIMARY KEY,
    username TEXT NOT NULL,
    password TEXT NOT NULL
);
-- Creeaz? tabela 'anunturi'
CREATE TABLE IF NOT EXISTS anunturi (
    id INT(11),
    titlu TEXT,
    descriere TEXT,
    data_publicarii DATE,
    autor TEXT,
    categorie TEXT
);

-- Creeaz? tabela 'echipe'
CREATE TABLE IF NOT EXISTS echipe (
    id INT(11) AUTO_INCREMENT PRIMARY KEY,
    nume TEXT,
    rol TEXT,
    echipa_id TEXT
);

-- Creeaz? tabela 'galerie'
CREATE TABLE IF NOT EXISTS galerie (
    id INT(11),
    imagine TEXT
);

-- Creeaz? tabela 'Sectii'
CREATE TABLE IF NOT EXISTS Sectii (
    id INT(11),
    sectie TEXT
);
