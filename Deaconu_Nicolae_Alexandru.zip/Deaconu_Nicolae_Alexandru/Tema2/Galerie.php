<?php
/*** mysql hostname ***/
$hostname = 'localhost';

/*** mysql username ***/
$username = 'Alex';

/*** mysql password ***/
$password = 'alexstudent';

try {
    $dbh = new PDO("mysql:host=$hostname;dbname=tema2", $username, $password);
    /*** echo a message saying we have connected ***/
    echo 'Connected to database';
}
catch(PDOException $e)
{
    echo $e->getMessage();
}
?>
<!DOCTYPE html>
<html lang="ro">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Galerie - Clubul Sportiv al lui Alex</title>
    <style>
        body {
            background-color: black;
            color: white;
            text-align: center;
        }

        img {
            max-width: 100%;
            height: auto;
            margin: 10px;
            border: 2px solid white;
        }
    </style>
</head>

<body>
<div class="navbar">
    <a href="Home.php">Acasă</a>
    <a href="Sectii.php">Sectii</a>
    <a href="Galerie.php">Galerie</a>
    <a href="Contact.php">Contact</a>
    <a href="Anunturi.php">Anunțuri</a>
    <a href="Echipe.php">Echipe</a>
</div>
    <h1>Galerie de imagini - Clubul Sportiv al lui Alex</h1>
    <div>
        <img src="Box.JPEG" alt="Box">
        <img src="MMA.JPEG" alt="MMA">
        <img src="Taekwondo.JPEG" alt="Taekwondo">
        <img src="Karate.JPEG" alt="Karate">
    </div>
</body>

</html>
