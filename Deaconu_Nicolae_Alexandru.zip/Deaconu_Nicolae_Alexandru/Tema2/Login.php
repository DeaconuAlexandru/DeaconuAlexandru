<?php
session_start();

if(isset($_SESSION['loggedin']) && $_SESSION['loggedin'] === true){
    header("location: home.php");
    exit;
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username_input = $_POST['username'];
    $password_input = $_POST['password'];

    $hostname = 'localhost';
    $username = 'Alex';
    $password = 'alexstudent';
    $dbname = 'tema2';

    try {
        $dbh = new PDO("mysql:host=$hostname;dbname=$dbname", $username, $password);

        // Am adaugat linia următoare pentru a selecta din tabela 'account'
        $stmt = $dbh->prepare("SELECT * FROM account WHERE user = :username AND password = :password");
        $stmt->bindParam(':username', $username_input);
        $stmt->bindParam(':password', $password_input);
        $stmt->execute();

        if ($stmt->rowCount() > 0) {
            $_SESSION['loggedin'] = true;
            header("location: home.php");
            exit;
        } else {
            echo "Nume de utilizator sau parolă incorectă!";
        }

    } catch (PDOException $e) {
        echo "Eroare de conectare la baza de date: " . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Formular de Login</title>
    <style>
        body {
            background-color: yellow;
            color: black;
            font-weight: bold;
        }
    </style>
</head>
<body>

<h2 align = "center">Formular de Login</h2>

<form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
    <div style = "text-align: center">
        <label for="username">Username:</label>
        <input type="text" id="username" name="username" required>
    </div>
    <div style = "text-align: center">
        <label for="password">Parola:</label>
        <input type="password" id="password" name="password" required>
    </div>
    <div style = "text-align: center">
        <button type="submit">Login</button>
    </div>
</form>

</body>
</html>

