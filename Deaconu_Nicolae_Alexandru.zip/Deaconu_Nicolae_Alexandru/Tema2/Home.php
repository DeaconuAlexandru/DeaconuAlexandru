<?php
session_start(); // A inceput sesiunea pentru pentru a avea acces la variabilele de sesiune

// Se verifica dacă utilizatorul este autentificat
if(isset($_SESSION['loggedin']) && $_SESSION['loggedin'] === true){
    $login_display_style = "display: none;"; // Cu aceasta functie ascudem butonul de login
    $logout_display_style = ""; // Se afiseaza butonul de logout
} else {
    $login_display_style = ""; // Se afiseaza butonul de login
    $logout_display_style = "display: none;"; // Am  ascuns  butonul de logout
}
?>

<!DOCTYPE html>
<html lang="ro">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Clubul Sportiv al lui Alex</title>
    <style>
        body {
            background-color: black; /* Am setat culoarea de fundal a paginii */
            color: lightyellow; /* Am setat culoarea textului */
        }

        h1 {
            text-align: center; /* Am centrat titlul */
        }

        p {
            margin-bottom: 20px; /* Am adaugat un spațiu inferior la paragrafe */
        }

        ul {
            margin-bottom: 20px; /* Am adaugat un spațiu inferior la liste */
        }

        li {
            margin-left: 20px; /* Am adaugat un spațiu la stânga elementelor de listă */
        }

        strong {
            color: pink; /* Am adaugat culoarea textului îngroșat */
        }

        .login-button, .logout-button {
            background-color: blue; /* Am setat culoarea de fundal albastra pentru butoane */
            color: white; /* Am setat culoarea textului alba */
            padding: 10px 20px; /* Am adaugat spatiu interior butoanelor */
            text-decoration: none; /* Aici am eliminat sublinierea textului */
            border-radius: 5px; /* Am adaugat colturi rotunjite la butoane */
        }

        .login-button:hover, .logout-button:hover {
            background-color: #0056b3; /* Am pus o nuanta mai închisa pentru efectul de hover */
        }

        .login-button {
            <?php echo $login_display_style; ?> /* Am aplicat stilul pentru afișare/ascundere a butonului de login */
        }

        .logout-button {
            <?php echo $logout_display_style; ?> /* Am aplicat stilul pentru afișare/ascundere a butonului de logout */
        }
    </style>
</head>

<body>
    <div class="navbar">
        <a href="Home.php">Acasă</a> <!-- Link către pagina Acasă -->
        <a href="Sectii.php">Sectii</a> <!-- Link către pagina Sectii -->
        <a href="Galerie.php">Galerie</a> <!-- Link către pagina Galerie -->
        <a href="Contact.php">Contact</a> <!-- Link către pagina Contact -->
        <a href="Anunturi.php">Anunțuri</a> <!-- Link către pagina Anunțuri -->
        <a href="Echipe.php">Echipe</a> <!-- Link către pagina Echipe -->
        <a href="Logout.php" class="logout-button">Logout</a> <!-- Buton de Logout -->
        <a href="Login.php" class="login-button">Login</a> <!-- Buton de Login -->
    </div>
    <h1>Clubul Sportiv al lui Alex</h1> <!-- Titlul principal al paginii -->
    <p>Acum ești în secțiunea Home, a clubului sportiv al lui Alex.</p> <!-- Descriere a secțiunii curente -->
    <p>Termenul de arte marțiale se referă la toate sistemele de pregătire pentru luptă care au fost aranjate sau sistematizate. În general, aceste sisteme sau stiluri diferite sunt concepute pentru un singur scop: înfrângerea fizică a adversarilor și apărarea împotriva amenințărilor. De fapt, cuvântul “marțial” provine din numele Marte, care era zeul roman al războiului.</p>
    <p>Fiecare civilizație subscrie la o versiune a artelor marțiale sau o combinație a acestora. Totuși, majoritatea oamenilor se gândesc la Asia atunci când au auzit termenul de arte marțiale. Odată cu aceasta, în jurul anului 600 î.en comerțul dintre India și China a înflorit. Se crede că în acest timp informații despre artele marțiale indiene au fost transmise chinezilor și vice versa.</p>
    <p>Potrivit legendei, un călugăr indian numit Bodhidharma a facilitat transmiterea Chan (China) sau Zen (Japonia) în China atunci când sa mutat în sudul Chinei. Învățăturile sale au împrumutat mult filozofiile artelor marțiale, cum ar fi umilința și reținerea, care continuă și astăzi. De fapt, unii l-au creditat pe Bodhidharma cu inițierea artelor marțiale Shaolin, deși această afirmație a fost discreditată de mulți.</p>
    <p>Artele marțiale pot fi împărțite în cinci categorii distincte: stiluri de stand-up sau striking, stiluri de luptă, stiluri de impact reduse, stiluri bazate pe arme și MMA (un stil sportiv hibrid).</p>
    <p>Câteva dintre cele mai cunoscute stiluri de Arte Marțiale:</p>
    <ul>
        <li>Itosu Anko - “bunicul Karate-ului”</li>
        <li>Helia Gracie - inventatorul Jiu Jitsu-lui Brazilian</li>
        <li>Royce Gracie - câștigător a trei din primele turnee UFC</li>
        <li>Jigoro Kano - inventatorul Kodokan Judo</li>
        <li>Bruce Lee - fondatorul Jeet Kune Do</li>
    </ul>
</body>

</html>
