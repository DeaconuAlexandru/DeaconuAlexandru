<?php
// Se porneste sesiunea sesiunea
session_start();

// Am setat datele de conectare la baza de date
$hostname = 'localhost';
$username = 'Alex';
$password = 'alexstudent';
$dbname = 'tema2';

// Am incercat sa ne conectam la baza de date folosind PDO
try {
    $dbh = new PDO("mysql:host=$hostname;dbname=$dbname", $username, $password);
    $dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    echo "Eroare la conectare: " . $e->getMessage();
    exit;
}

// Am pus pentru adaugarea unui membru în echipa
function adaugaMembru($nume, $rol, $echipa_id) {
    global $dbh;

    try {
        $stmt = $dbh->prepare("INSERT INTO echipe (nume, rol, echipa_id) VALUES (:nume, :rol, :echipa_id)");
        $stmt->bindParam(':nume', $nume);
        $stmt->bindParam(':rol', $rol);
        $stmt->bindParam(':echipa_id', $echipa_id);
        $stmt->execute();
        echo "Membrul a fost adăugat cu succes!";
    } catch (PDOException $e) {
        echo "Eroare la adăugarea membrului: " . $e->getMessage();
    }
}

// Am pus o functie pentru retragerea unui luptator din echipa
function retrageLuptator($nume) {
    global $dbh;

    try {
        $stmt = $dbh->prepare("DELETE FROM echipe WHERE nume = :nume");
        $stmt->bindParam(':nume', $nume);
        $stmt->execute();
        echo "Luptătorul a fost retras cu succes!";
    } catch (PDOException $e) {
        echo "Eroare la retragerea luptătorului: " . $e->getMessage();
    }
}

// Am creat o pentru modificarea rolului unui luptator din echipa
function modificaLuptator($nume, $rol_modificat, $pozitie) {
    global $dbh;

    try {
        // Se verifica rolul curent al luptatorului
        $stmt = $dbh->prepare("SELECT rol FROM echipe WHERE nume = :nume");
        $stmt->bindParam(':nume', $nume);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($row) {
            $rol_vechi = $row['rol'];
            // Am determinat noul rol bazat pe poziția specificata
            if ($pozitie == 'before') {
                $rol_nou = $rol_modificat . ", " . $rol_vechi;
            } elseif ($pozitie == 'after') {
                $rol_nou = $rol_vechi . ", " . $rol_modificat;
            } elseif ($pozitie == 'replace') {
                $rol_nou = $rol_modificat;
            } else {
                echo "Poziție invalidă!";
                return;
            }

            // Am actualizat rolul în baza de date
            $stmt = $dbh->prepare("UPDATE echipe SET rol = :rol_nou WHERE nume = :nume");
            $stmt->bindParam(':rol_nou', $rol_nou);
            $stmt->bindParam(':nume', $nume);
            $stmt->execute();
            echo "Rolul membrului a fost modificat cu succes!";
        } else {
            echo "Membrul nu a fost găsit!";
        }
    } catch (PDOException $e) {
        echo "Eroare la modificarea rolului membrului: " . $e->getMessage();
    }
}

// Am verificat daca formularul a fost trimis
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] === true) {
        // Se adauga un membru nou
        if (isset($_POST['nume']) && isset($_POST['rol']) && isset($_POST['echipa_id'])) {
            $nume = $_POST['nume'];
            $rol = $_POST['rol'];
            $echipa_id = $_POST['echipa_id'];
            adaugaMembru($nume, $rol, $echipa_id);
        }
        // Aici retragem un luptator
        elseif (isset($_POST['retrage_luptator'])) {
            $nume_luptator = $_POST['nume_luptator'];
            retrageLuptator($nume_luptator);
        }
        // Se modifica rolul unui luptator
        elseif (isset($_POST['modifica_luptator'])) {
            $nume_modifica = $_POST['nume_modifica'];
            $rol_modificat = $_POST['rol_modificat'];
            $pozitie = $_POST['pozitie'];
            modificaLuptator($nume_modifica, $rol_modificat, $pozitie);
        }
    } else {
        echo "Trebuie să fii autentificat pentru a adăuga, retrage sau modifica membri.";
    }
}
?>

<!DOCTYPE html>
<html lang="ro">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Echipe - Clubul Sportiv al lui Alex și Sorin</title>
    <style>
        body {
            background-color: black;
            color: cadetblue;
            font-family: Arial, sans-serif;
        }

        h1 {
            text-align: center;
        }

        .team {
            margin-bottom: 30px;
        }

        .team h2 {
            color: pink;
            font-size: 20px;
            margin-bottom: 10px;
        }

        .team ul {
            list-style-type: none;
            padding-left: 0;
        }

        .team li {
            margin-bottom: 10px;
        }

        .team li strong {
            color: pink;
        }
    </style>
</head>

<body>
    <div class="navbar">
        <a href="Home.php">Acasă</a>
        <a href="Sectii.php">Sectii</a>
        <a href="Galerie.php">Galerie</a>
        <a href="Contact.php">Contact</a>
        <a href="Anunturi.php">Anunțuri</a>
        <a href="Echipe.php">Echipe</a>
    </div>
    <h1>Echipe - Clubul Sportiv al lui Alex și Sorin</h1>

    <div class="team">
        <h2>Echipa lui Alex:</h2>
        <ul>
            <li><strong>Alex:</strong> coordonator, șef universal, antreprenor, începător</li>
            <li><strong>Adrian:</strong> coordonator de gradul 2, cu un grad mai jos decât Alex, investitor de afaceri</li>
            <li><strong>Madalin:</strong> Manager, antreprenor</li>
            <li><strong>Ioana:</strong> practicantă de Taekwondo</li>
            <li><strong>Albert:</strong> practicant de Karate</li>
            <li><strong>Mihai:</strong> practicant de Box</li>
            <li><strong>Ana:</strong> practicantă de MMA</li>
            <li><strong>Isabela:</strong> Contabilă</li>
            <li><strong>Andrei:</strong> practicant de KickBoxing</li>
            <!-- Se afiseaza membrii echipei lui Alex din baza de date -->
            <?php
            try {
                $stmt = $dbh->prepare("SELECT * FROM echipe WHERE echipa_id = 'Alex'");
                $stmt->execute();
                while ($row = $stmt->fetch()) {
                    echo "<li><strong>" . $row['nume'] . ":</strong> " . $row['rol'] . "</li>";
                }
            } catch (PDOException $e) {
                echo "Eroare la afișarea echipei lui Alex: " . $e->getMessage();
            }
            ?>
        </ul>
        <p>Asta este echipa lui Alex.</p>
    </div>

    <div class="team">
        <h2>Echipa lui Sorin:</h2>
        <ul>
            <li><strong>Sorin:</strong> coordonator, șef universal, antreprenor, începător</li>
            <li><strong>Andrei:</strong> coordonator de gradul 2, cu un grad mai jos decât Sorin, investitor de afaceri</li>
            <li><strong>Costel:</strong> Manager, antreprenor</li>
            <li><strong>Mihaela:</strong> practicantă de Taekwondo</li>
            <li><strong>Aang:</strong> practicant de Karate</li>
            <li><strong>Marian:</strong> practicant de Box</li>
            <li><strong>Floricica:</strong> practicantă de MMA</li>
            <li><strong>Naofumi:</strong> Contabilă</li>
            <li><strong>Andreea:</strong> practicantă de KickBoxing</li>
            <!-- Se afiseaza membrii echipei lui Sorin din baza de date -->
            <?php
            try {
                $stmt = $dbh->prepare("SELECT * FROM echipe WHERE echipa_id = 'Sorin'");
                $stmt->execute();
                while ($row = $stmt->fetch()) {
                    echo "<li><strong>" . $row['nume'] . ":</strong> " . $row['rol'] . "</li>";
                }
            } catch (PDOException $e) {
                echo "Eroare la afișarea echipei lui Sorin: " . $e->getMessage();
            }
            ?>
        </ul>
        <p>Asta este echipa lui Sorin.</p>
    </div>

    <p>
        Deși termenii „arte marțiale” și „sporturi de luptă” sunt deseori folosiți în mod interschimbabil, aceștia
        reprezintă de fapt două abordări diferite ale activităților fizice de luptă și autoapărare. Scopul principal al
        artelor marțiale este de a dezvolta abilități de autoapărare, un spirit războinic, o filozofie de viață și
        armonie între corp și minte. Ele sunt adesea legate de tradiții culturale și istorice, iar unele au și aspecte
        spirituale și etice. Multe arte marțiale tradiționale, cum ar fi judo, kung-fu sau aikido, pun accentul pe
        dezvoltarea caracterului, pe respectul față de ceilalți și pe autocontrol. Deși artele marțiale au reguli, ele
        pot fi adesea mai flexibile în ceea ce privește antrenamentul și practica. Scopul este de a perfecționa
        tehnicile și de a dobândi abilități care pot fi aplicate într-o varietate de situații de viață.
    </p>

    <p>
        Sporturile de luptă, pe de altă parte, se concentrează pe competiție și pe aplicarea unor reguli specifice pentru
        a determina un câștigător. Concurenții se luptă între ei pentru a obține puncte, pentru a câștiga prin KO tehnic
        (TKO) sau pentru ca adversarul lor să se supună, în conformitate cu regulile sportului respectiv. Sporturile de
        luptă sunt strict reglementate de organizațiile sportive, care stabilesc regulile de luptă, categoriile de
        greutate, tipurile de lovituri permise, protecția concurenților etc.
    </p>

    <p>
        Merită menționat faptul că unele arte marțiale sunt, de asemenea, sporturi de luptă, cum ar fi: MMA, wrestling,
        jiu-jitsu brazilian, Muay Thai, kickboxing, karate sau taekwondo.
    </p>

    <p>
        Printre cele mai populare sporturi și arte marțiale se numără boxul, wrestlingul, karate, kick boxing, MMA, judo,
        taekwondo, Muay Thai sau jiu-jitsu brazilian. Fiecare disciplină are propriile caracteristici și reguli unice,
        dar toate necesită tărie, disciplină și multă muncă pentru a reuși în competiție sau pentru a dezvolta abilități
        fizice, spirituale și morale.
    </p>

    <?php if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] === true): ?>
        <!-- Formular pentru adăugarea unui membru nou -->
        <h2>Adaugă membru nou</h2>
        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
            <div>
                <label for="nume">Nume:</label>
                <input type="text" id="nume" name="nume" required>
            </div>
            <div>
                <label for="rol">Rol:</label>
                <input type="text" id="rol" name="rol" required>
            </div>
            <div>
                <label for="echipa_id">Echipa:</label>
                <select id="echipa_id" name="echipa_id">
                    <option value="Alex">Alex</option>
                    <option value="Sorin">Sorin</option>
                </select>
            </div>
            <div>
                <button type="submit">Adaugă Membru</button>
            </div>
        </form>

        <!-- Formular pentru modificarea rolului unui luptător -->
        <h2>Modifică Roluri Luptător</h2>
        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
            <div>
                <label for="nume_modifica">Nume Luptător:</label>
                <input type="text" id="nume_modifica" name="nume_modifica" required>
            </div>
            <div>
                <label for="rol_modificat">Rol Nou:</label>
                <input type="text" id="rol_modificat" name="rol_modificat" required>
            </div>
            <div>
                <label for="pozitie">Poziție:</label>
                <select id="pozitie" name="pozitie">
                    <option value="before">Înainte</option>
                    <option value="after">După</option>
                    <option value="replace">Înlocuiește</option>
                </select>
            </div>
            <div>
                <button type="submit" name="modifica_luptator">Modifică Rol</button>
            </div>
        </form>

        <!-- Formular pentru retragerea unui luptător -->
        <h2>Retragere luptător</h2>
        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
            <div>
                <label for="nume_luptator">Nume Luptător:</label>
                <input type="text" id="nume_luptator" name="nume_luptator" required>
            </div>
            <div>
                <button type="submit" name="retrage_luptator">Retrage Luptător</button>
            </div>
        </form>

    <?php endif; ?>
</body>

</html>
