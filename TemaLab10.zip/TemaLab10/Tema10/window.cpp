#include "window.h"
#include "ui_window.h"

#include <QFileDialog>
#include <QMessageBox>
#include <QPainter>
#include <QMouseEvent>
#include <QColor>

Window::Window(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::Window)
    , dragging(false)
{
    ui->setupUi(this);
}

Window::~Window()
{
    delete ui;
}

// Incarca poza principala
void Window::on_btnLoad_clicked()
{
    QString fileName = QFileDialog::getOpenFileName(this, "Selecteaza poza", "",
                                                    "Imagini (*.jpg *.jpeg *.png *.bmp *.tiff);;Toate fisierele (*.*)");

    if (fileName.isEmpty()) return;

    if (!baseImage.load(fileName)) {
        QMessageBox::critical(this, "Eroare", "Nu s-a putut incarca poza.");
        return;
    }

    if (!hatImage.isNull())
        hatPos = QPoint(baseImage.width()/2, 50);

    updateDisplay();
}

// Transformam JPG/PNG caciula -> fundal transparent
QPixmap Window::makeHatTransparent(const QPixmap &pixmap)
{
    QImage img = pixmap.toImage().convertToFormat(QImage::Format_ARGB32);

    QColor bgColor = img.pixelColor(0, 0); // presupunem coltul ca fundal

    for(int y = 0; y < img.height(); ++y){
        for(int x = 0; x < img.width(); ++x){
            QColor c = img.pixelColor(x, y);

            // daca e foarte apropiat de fundal -> transparent
            int diff = qAbs(c.red() - bgColor.red()) +
                       qAbs(c.green() - bgColor.green()) +
                       qAbs(c.blue() - bgColor.blue());

            if(diff < 30) { // toleranta 30
                c.setAlpha(0);
                img.setPixelColor(x, y, c);
            }
        }
    }

    return QPixmap::fromImage(img);
}

// Incarca caciula
void Window::on_btnHatLoad_clicked()
{
    QString fileName = QFileDialog::getOpenFileName(this, "Selecteaza caciula", "",
                                                    "Imagini (*.jpg *.jpeg *.png *.bmp);;Toate fisierele (*.*)");

    if (fileName.isEmpty()) return;

    QPixmap temp;
    if (!temp.load(fileName)) {
        QMessageBox::critical(this, "Eroare", "Nu s-a putut incarca caciula.");
        return;
    }

    hatImage = makeHatTransparent(temp);

    if (!baseImage.isNull())
        hatPos = QPoint(baseImage.width()/2, 50);

    QMessageBox::information(this, "OK", "Caciula a fost incarcata cu fundal transparent!");
    updateDisplay();
}

// Redesenam poza + caciula
void Window::updateDisplay()
{
    if (baseImage.isNull()) return;

    QPixmap result(baseImage.size());
    result.fill(Qt::transparent);

    QPainter painter(&result);
    painter.setCompositionMode(QPainter::CompositionMode_Source);
    painter.drawPixmap(0, 0, baseImage);

    if (!hatImage.isNull()) {
        int hatWidth = baseImage.width()/3;
        int hatHeight = hatImage.height()*hatWidth/hatImage.width();
        int x = hatPos.x() - hatWidth/2;
        int y = hatPos.y() - hatHeight/2;

        painter.setCompositionMode(QPainter::CompositionMode_SourceOver);
        painter.drawPixmap(x, y, hatWidth, hatHeight, hatImage);
    }

    painter.end();

    displayImage = result;
    ui->imageLabel->setPixmap(displayImage.scaled(ui->imageLabel->size(),
                                                  Qt::KeepAspectRatio, Qt::SmoothTransformation));
}

// Aplica caciula definitiv
void Window::on_btnHat_clicked()
{
    if (baseImage.isNull() || hatImage.isNull()) return;

    QPainter painter(&baseImage);
    int hatWidth = baseImage.width()/3;
    int hatHeight = hatImage.height()*hatWidth/hatImage.width();
    int x = hatPos.x() - hatWidth/2;
    int y = hatPos.y() - hatHeight/2;

    painter.setCompositionMode(QPainter::CompositionMode_SourceOver);
    painter.drawPixmap(x, y, hatWidth, hatHeight, hatImage);
    painter.end();

    updateDisplay();
    QMessageBox::information(this, "OK", "Caciula a fost aplicata pe poza!");
}

// Salvare imagine
void Window::on_btnSave_clicked()
{
    if (displayImage.isNull()) return;

    QString fileName = QFileDialog::getSaveFileName(this, "Salveaza imagine", "",
                                                    "PNG (*.png);;JPG (*.jpg *.jpeg)");

    if (fileName.isEmpty()) return;

    if (fileName.endsWith(".png")) {
        displayImage.toImage().save(fileName, "PNG");
    } else {
        displayImage.save(fileName);
    }
}

// Drag & drop caciula
void Window::mousePressEvent(QMouseEvent *event)
{
    if (hatImage.isNull()) return;

    int w = baseImage.width()/3;
    int h = hatImage.height()*w/hatImage.width();
    QRect rect(hatPos.x()-w/2, hatPos.y()-h/2, w, h);

    if (rect.contains(event->pos())) {
        dragging = true;
        dragOffset = event->pos() - hatPos;
    }
}

void Window::mouseMoveEvent(QMouseEvent *event)
{
    if (dragging) {
        hatPos = event->pos() - dragOffset;
        updateDisplay();
    }
}

void Window::mouseReleaseEvent(QMouseEvent *event)
{
    Q_UNUSED(event);
    dragging = false;
}
