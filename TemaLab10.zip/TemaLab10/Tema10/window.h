#ifndef WINDOW_H
#define WINDOW_H

#include <QMainWindow>
#include <QPixmap>
#include <QPoint>

QT_BEGIN_NAMESPACE
namespace Ui { class Window; }
QT_END_NAMESPACE

class Window : public QMainWindow
{
    Q_OBJECT

public:
    explicit Window(QWidget *parent = nullptr);
    ~Window();

private slots:
    void on_btnLoad_clicked();
    void on_btnHatLoad_clicked();
    void on_btnHat_clicked();
    void on_btnSave_clicked();

protected:
    void mousePressEvent(QMouseEvent *event) override;
    void mouseMoveEvent(QMouseEvent *event) override;
    void mouseReleaseEvent(QMouseEvent *event) override;

private:
    Ui::Window *ui;

    QPixmap baseImage;      // poza principala
    QPixmap hatImage;       // caciula
    QPixmap displayImage;   // pentru afisare si salvare

    QPoint hatPos;          // pozitia caciulii
    bool dragging;          // daca caciula e mutata
    QPoint dragOffset;      // offset la drag

    QPixmap makeHatTransparent(const QPixmap &pixmap); // fundal transparent
    void updateDisplay();   // redesenam poza + caciula
};

#endif // WINDOW_H
