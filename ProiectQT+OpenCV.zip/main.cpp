#include <opencv2/opencv.hpp>
#include <iostream>
#include <string>

using namespace cv;
using namespace std;

int main() {
    string basePath = "C:\\\\Users\\\\deaco\\\\OneDrive\\\\Desktop\\\\C++Projects\\\\Proiect\\\\";
    string alexPath = basePath + "Alex.jpg";
    string gagicaPath = basePath + "Gagica.png";
    string bubblePath = basePath + "text.png";
    string outputVideo = basePath + "animatie.avi";

    Mat alex = imread(alexPath);
    Mat gagica = imread(gagicaPath);
    Mat bubble = imread(bubblePath, IMREAD_UNCHANGED);

    if (alex.empty() || gagica.empty() || bubble.empty()) {
        cout << "Eroare la incarcare imagini." << endl;
        return -1;
    }

    // Redimensionam gagica la aceeasi inaltime cu Alex
    if (gagica.rows != alex.rows) {
        double scale = (double)alex.rows / gagica.rows;
        resize(gagica, gagica, Size(int(gagica.cols * scale), alex.rows));
    }

    // Cream fundalul final: Alex + Gagica
    int totalWidth = alex.cols + gagica.cols;
    int totalHeight = max(alex.rows, gagica.rows);
    Mat background(totalHeight, totalWidth, alex.type());

    alex.copyTo(background(Rect(0, 0, alex.cols, alex.rows)));
    gagica.copyTo(background(Rect(alex.cols, 0, gagica.cols, gagica.rows)));

    // Redimensionam bula
    int newWidth = background.cols / 3;
    int newHeight = (bubble.rows * newWidth) / bubble.cols;
    resize(bubble, bubble, Size(newWidth, newHeight));

    // Bula oglindita pentru gagica
    Mat bubbleFlipped;
    flip(bubble, bubbleFlipped, 1);

    // Video writer
    int fps = 24;
    VideoWriter writer(outputVideo, VideoWriter::fourcc('M', 'J', 'P', 'G'), fps, background.size());
    if (!writer.isOpened()) {
        cout << "Eroare la salvarea video." << endl;
        return -1;
    }

    // Pozitii pentru bule
    Point posAlex(50, 50);
    Point posGagica(background.cols - newWidth - 50, 50);

    // Textele din conversatie
    string text1 = "Ce faci frumoas-o, iesi in oras cu mine diseara la un restaurant?";
    string text2 = "Desigur aratosule, iesim diseara, abia astept.";
    string text3 = "Perfect, te iau la 8?";
    string text4 = "Da, abia astept sa fiu cu tine.";
    string text5 = "Bine, ne vedem la 8.";

    // Functie fade-in + text
    auto addBubble = [&](Mat& frame, Mat& bubbleImg, Point pos, string text) {
        for (double alpha = 0.0; alpha <= 1.0; alpha += 0.05) {
            Mat overlay;
            frame.copyTo(overlay);
            for (int y = 0; y < bubbleImg.rows; y++) {
                for (int x = 0; x < bubbleImg.cols; x++) {
                    Vec4b pixel = bubbleImg.at<Vec4b>(y, x);
                    if (pixel[3] > 0) {
                        Vec3b& destPixel = overlay.at<Vec3b>(pos.y + y, pos.x + x);
                        destPixel[0] = pixel[0];
                        destPixel[1] = pixel[1];
                        destPixel[2] = pixel[2];
                    }
                }
            }
            addWeighted(overlay, alpha, frame, 1 - alpha, 0, overlay);
            putText(overlay, text, Point(pos.x + 20, pos.y + bubbleImg.rows / 2),
                    FONT_HERSHEY_SIMPLEX, 0.7, Scalar(0, 0, 0), 2);
            writer.write(overlay);
        }
        for (int i = 0; i < 25; i++) {
            Mat temp;
            frame.copyTo(temp);
            for (int y = 0; y < bubbleImg.rows; y++) {
                for (int x = 0; x < bubbleImg.cols; x++) {
                    Vec4b pixel = bubbleImg.at<Vec4b>(y, x);
                    if (pixel[3] > 0) {
                        Vec3b& destPixel = temp.at<Vec3b>(pos.y + y, pos.x + x);
                        destPixel[0] = pixel[0];
                        destPixel[1] = pixel[1];
                        destPixel[2] = pixel[2];
                    }
                }
            }
            putText(temp, text, Point(pos.x + 20, pos.y + bubbleImg.rows / 2),
                    FONT_HERSHEY_SIMPLEX, 0.7, Scalar(0, 0, 0), 2);
            writer.write(temp);
        }
    };

    // Functie fade-out
    auto removeBubble = [&](Mat& frame, Mat& bubbleImg, Point pos, string text) {
        for (double alpha = 1.0; alpha >= 0.0; alpha -= 0.05) {
            Mat overlay;
            frame.copyTo(overlay);
            for (int y = 0; y < bubbleImg.rows; y++) {
                for (int x = 0; x < bubbleImg.cols; x++) {
                    Vec4b pixel = bubbleImg.at<Vec4b>(y, x);
                    if (pixel[3] > 0) {
                        Vec3b& destPixel = overlay.at<Vec3b>(pos.y + y, pos.x + x);
                        destPixel[0] = pixel[0];
                        destPixel[1] = pixel[1];
                        destPixel[2] = pixel[2];
                    }
                }
            }
            addWeighted(overlay, alpha, frame, 1 - alpha, 0, overlay);
            putText(overlay, text, Point(pos.x + 20, pos.y + bubbleImg.rows / 2),
                    FONT_HERSHEY_SIMPLEX, 0.7, Scalar(0, 0, 0), 2);
            writer.write(overlay);
        }
    };

    // Conversatia
    Mat scena = background.clone();
    addBubble(scena, bubble, posAlex, text1);
    removeBubble(scena, bubble, posAlex, text1);

    scena = background.clone();
    addBubble(scena, bubbleFlipped, posGagica, text2);
    removeBubble(scena, bubbleFlipped, posGagica, text2);

    scena = background.clone();
    addBubble(scena, bubble, posAlex, text3);
    removeBubble(scena, bubble, posAlex, text3);

    scena = background.clone();
    addBubble(scena, bubbleFlipped, posGagica, text4);
    removeBubble(scena, bubbleFlipped, posGagica, text4);

    scena = background.clone();
    addBubble(scena, bubble, posAlex, text5);
    removeBubble(scena, bubble, posAlex, text5);

    writer.release();
    cout << "Animatia a fost salvata la: " << outputVideo << endl;

    return 0;
}
