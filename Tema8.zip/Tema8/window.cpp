#include "window.h"
#include <QImage>
#include <QPixmap>
#include <opencv2/imgproc.hpp>

Window::Window(QWidget *parent)
    : QMainWindow(parent),
    ui(new Ui::Window),
    timer(new QTimer(this)),
    hasLast(false)
{
    ui->setupUi(this);

    // Deschide camera
    cap.open(0);

    drawingLayer = cv::Mat::zeros(480, 640, CV_8UC3);

    // valori default HSV
    lowH = 75;  highH = 130;
    lowS = 120; highS = 255;
    lowV = 46;  highV = 255;

    // set slider-ele și maximul la 255
    ui->sliderLowH->setMaximum(255); ui->sliderLowH->setValue(lowH);
    ui->sliderHighH->setMaximum(255); ui->sliderHighH->setValue(highH);
    ui->sliderLowS->setMaximum(255); ui->sliderLowS->setValue(lowS);
    ui->sliderHighS->setMaximum(255); ui->sliderHighS->setValue(highS);
    ui->sliderLowV->setMaximum(255); ui->sliderLowV->setValue(lowV);
    ui->sliderHighV->setMaximum(255); ui->sliderHighV->setValue(highV);

    // timer pentru update frame
    connect(timer, &QTimer::timeout, this, &Window::updateFrame);
    timer->start(30);

    // buton Clear
    connect(ui->pushButtonClear, &QPushButton::clicked, this, &Window::clearDrawing);

    // slider update HSV + label + console
    auto updateHSV = [this]() {
        updateHSVValues();
    };

    connect(ui->sliderLowH, &QSlider::valueChanged, updateHSV);
    connect(ui->sliderHighH, &QSlider::valueChanged, updateHSV);
    connect(ui->sliderLowS, &QSlider::valueChanged, updateHSV);
    connect(ui->sliderHighS, &QSlider::valueChanged, updateHSV);
    connect(ui->sliderLowV, &QSlider::valueChanged, updateHSV);
    connect(ui->sliderHighV, &QSlider::valueChanged, updateHSV);

    // initializare label-uri valori
    updateHSVValues();
}

Window::~Window() {
    cap.release();
    delete ui;
}

void Window::updateHSVValues() {
    lowH = ui->sliderLowH->value();
    highH = ui->sliderHighH->value();
    lowS = ui->sliderLowS->value();
    highS = ui->sliderHighS->value();
    lowV = ui->sliderLowV->value();
    highV = ui->sliderHighV->value();

    // update label-uri
    ui->labelLowHValue->setText(QString("%1 / 255").arg(lowH));
    ui->labelHighHValue->setText(QString("%1 / 255").arg(highH));
    ui->labelLowSValue->setText(QString("%1 / 255").arg(lowS));
    ui->labelHighSValue->setText(QString("%1 / 255").arg(highS));
    ui->labelLowVValue->setText(QString("%1 / 255").arg(lowV));
    ui->labelHighVValue->setText(QString("%1 / 255").arg(highV));

    // debug consola WithQt
    qDebug() << "HSV Values:"
             << "LowH=" << lowH << "HighH=" << highH
             << "LowS=" << lowS << "HighS=" << highS
             << "LowV=" << lowV << "HighV=" << highV;
}

void Window::clearDrawing() {
    drawingLayer = cv::Mat::zeros(480, 640, CV_8UC3);
    hasLast = false;
}

void Window::updateFrame() {
    if (!cap.isOpened()) return;

    cap >> frame;
    if (frame.empty()) return;

    cv::flip(frame, frame, 1);

    // HSV
    cv::Mat hsv;
    cv::cvtColor(frame, hsv, cv::COLOR_BGR2HSV);

    // MASK cu sliders
    cv::Scalar lower(lowH, lowS, lowV);
    cv::Scalar upper(highH, highS, highV);

    cv::Mat mask;
    cv::inRange(hsv, lower, upper, mask);

    // contur principal
    std::vector<std::vector<cv::Point>> contours;
    cv::findContours(mask, contours, cv::RETR_EXTERNAL, cv::CHAIN_APPROX_SIMPLE);

    if (!contours.empty()) {
        size_t best = 0;
        double maxArea = 0;
        for (size_t i = 0; i < contours.size(); i++) {
            double a = cv::contourArea(contours[i]);
            if (a > maxArea) { maxArea = a; best = i; }
        }

        cv::Moments m = cv::moments(contours[best]);
        if (m.m00 > 2000) {
            cv::Point pt(m.m10/m.m00, m.m01/m.m00);

            if (ui->checkBoxWriting->isChecked()) {
                if (hasLast)
                    cv::line(drawingLayer, lastPoint, pt, cv::Scalar(255,0,0), 6);

                lastPoint = pt;
                hasLast = true;
            }
        }
    } else {
        hasLast = false;
    }

    // final image (webcam + desene)
    cv::Mat display;
    cv::addWeighted(frame, 0.7, drawingLayer, 0.3, 0, display);

    // CAM MARE
    ui->label->setPixmap(QPixmap::fromImage(
        QImage(display.data, display.cols, display.rows, display.step, QImage::Format_BGR888)));

    // PREVIEW MIC
    cv::Mat small;
    cv::resize(display, small, cv::Size(300, 170));
    ui->labelPreview->setPixmap(QPixmap::fromImage(
        QImage(small.data, small.cols, small.rows, small.step, QImage::Format_BGR888)));

    // MASK PREVIEW
    cv::Mat maskRGB;
    cv::cvtColor(mask, maskRGB, cv::COLOR_GRAY2BGR);
    cv::Mat maskSmall;
    cv::resize(maskRGB, maskSmall, cv::Size(300, 170));
    ui->labelMask->setPixmap(QPixmap::fromImage(
        QImage(maskSmall.data, maskSmall.cols, maskSmall.rows, maskSmall.step, QImage::Format_BGR888)));
}
