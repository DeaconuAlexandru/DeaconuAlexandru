#ifndef WINDOW_H
#define WINDOW_H

#include <QMainWindow>
#include <QTimer>
#include <QDebug>
#include "ui_window.h"
#include <opencv2/opencv.hpp>

class Window : public QMainWindow {
    Q_OBJECT

public:
    explicit Window(QWidget *parent = nullptr);
    ~Window();

private slots:
    void updateFrame();
    void clearDrawing();

private:
    Ui::Window *ui;
    cv::VideoCapture cap;
    QTimer *timer;

    cv::Mat frame;
    cv::Mat drawingLayer;

    cv::Point lastPoint;
    bool hasLast;

    int lowH, highH, lowS, highS, lowV, highV;

    void updateHSVValues();
};

#endif // WINDOW_H

