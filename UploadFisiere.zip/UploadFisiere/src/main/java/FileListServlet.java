import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class FileListServlet extends HttpServlet {
    private static final String UPLOAD_DIR = "C:/uploads";

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        File uploadDir = new File(UPLOAD_DIR);
        File[] files = uploadDir.listFiles();

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        out.println("<h1>Uploaded Files:</h1>");
        if (files != null) {
            for (File file : files) {
                out.println("<p><a href='" + UPLOAD_DIR + "/" + file.getName() + "'>" + file.getName() + "</a></p>");
            }
        } else {
            out.println("<p>No files uploaded yet.</p>");
        }
    }
}
