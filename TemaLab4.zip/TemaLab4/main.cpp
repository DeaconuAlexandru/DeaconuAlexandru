#include <QApplication>
#include <QMainWindow>
#include <QPushButton>
#include <QSlider>
#include <QLabel>
#include <QFileDialog>
#include <QColorDialog>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QImage>
#include <QPixmap>
#include <QMediaPlayer>
#include <QAudioOutput>
#include <QUrl>
#include <opencv2/opencv.hpp>

using namespace cv;

class MainWindow : public QMainWindow {
public:
    MainWindow(QWidget *parent = nullptr) : QMainWindow(parent) {
        QWidget *central = new QWidget(this);
        setCentralWidget(central);

        imageLabel = new QLabel("Incarca imaginea de baza", this);
        imageLabel->setAlignment(Qt::AlignCenter);
        imageLabel->setMinimumSize(600, 400);
        imageLabel->setStyleSheet("border: 1px solid black");

        QPushButton *btnLoadBase = new QPushButton("Incarca imagine de baza");
        QPushButton *btnLoadBg = new QPushButton("Incarca imagine fundal");
        QPushButton *btnColorBg = new QPushButton("Alege culoare fundal");
        QPushButton *btnSave = new QPushButton("Salveaza rezultat");

        sliderThreshold = new QSlider(Qt::Horizontal);
        sliderThreshold->setRange(0, 255);
        sliderThreshold->setValue(120);

        QHBoxLayout *controls = new QHBoxLayout();
        controls->addWidget(btnLoadBase);
        controls->addWidget(btnLoadBg);
        controls->addWidget(btnColorBg);
        controls->addWidget(btnSave);

        QVBoxLayout *layout = new QVBoxLayout();
        layout->addLayout(controls);
        layout->addWidget(new QLabel("Valoare threshold:"));
        layout->addWidget(sliderThreshold);
        layout->addWidget(imageLabel);

        central->setLayout(layout);

        connect(btnLoadBase, &QPushButton::clicked, this, [this]() { loadBase(); });
        connect(btnLoadBg, &QPushButton::clicked, this, [this]() { loadBackgroundImage(); });
        connect(btnColorBg, &QPushButton::clicked, this, [this]() { chooseColorBackground(); });
        connect(btnSave, &QPushButton::clicked, this, [this]() { saveResult(); });
        connect(sliderThreshold, &QSlider::valueChanged, this, [this]() { updatePreview(); });

        audioOutput = new QAudioOutput(this);
        player = new QMediaPlayer(this);
        player->setAudioOutput(audioOutput);
        player->setSource(QUrl::fromLocalFile("C:/Users/deaco/Downloads/SephirothTheme.mp3"));
        audioOutput->setVolume(0.5);
        player->setLoops(QMediaPlayer::Infinite);
    }

protected:
    void resizeEvent(QResizeEvent *event) override {
        QMainWindow::resizeEvent(event);
        updatePreview(); // actualizează imaginea la redimensionare
    }

private:
    QLabel *imageLabel;
    QSlider *sliderThreshold;
    cv::Mat base, bg, result;
    QColor bgColor;
    bool useColorBg = false;
    bool useImageBg = false;
    QMediaPlayer *player;
    QAudioOutput *audioOutput;

    void loadBase() {
        QString path = QFileDialog::getOpenFileName(this, "Alege imaginea de baza", "", "Imagini (*.png *.jpg *.jpeg *.bmp)");
        if (path.isEmpty()) return;
        base = imread(path.toStdString(), IMREAD_UNCHANGED);
        if (base.empty()) return;
        if(base.channels() == 4)
            cvtColor(base, base, COLOR_BGRA2BGR);

        if(player->playbackState() != QMediaPlayer::PlayingState)
            player->play();

        updatePreview();
    }

    void loadBackgroundImage() {
        QString path = QFileDialog::getOpenFileName(this, "Alege imagine fundal", "", "Imagini (*.png *.jpg *.jpeg *.bmp)");
        if (path.isEmpty()) return;
        bg = imread(path.toStdString());
        if (bg.empty()) return;
        useImageBg = true;
        useColorBg = false;
        updatePreview();
    }

    void chooseColorBackground() {
        QColor c = QColorDialog::getColor(Qt::white, this, "Alege culoare fundal");
        if (!c.isValid()) return;
        bgColor = c;
        useColorBg = true;
        useImageBg = false;
        updatePreview();
    }

    void saveResult() {
        if (result.empty()) return;
        QString path = QFileDialog::getSaveFileName(this, "Salveaza rezultatul", "", "Imagini (*.png *.jpg)");
        if (path.isEmpty()) return;
        imwrite(path.toStdString(), result);
    }

    void updatePreview() {
        if (base.empty()) return;

        // folosește dimensiunea label-ului pentru redimensionare
        cv::Size targetSize(imageLabel->width(), imageLabel->height());
        cv::Mat baseResized;
        cv::resize(base, baseResized, targetSize);

        cv::Mat gray;
        cv::cvtColor(baseResized, gray, cv::COLOR_BGR2GRAY);

        cv::equalizeHist(gray, gray);

        int threshVal = sliderThreshold->value();
        cv::Mat mask;
        cv::threshold(gray, mask, threshVal, 255, THRESH_BINARY_INV);

        cv::Mat kernel = cv::getStructuringElement(MORPH_ELLIPSE, Size(9,9));
        cv::morphologyEx(mask, mask, MORPH_OPEN, kernel, Point(-1,-1), 4);
        cv::morphologyEx(mask, mask, MORPH_CLOSE, kernel, Point(-1,-1), 4);
        cv::dilate(mask, mask, kernel, Point(-1,-1), 2);
        cv::erode(mask, mask, kernel, Point(-1,-1), 2);

        cv::Mat labels, stats, centroids;
        int num = cv::connectedComponentsWithStats(mask, labels, stats, centroids);
        for(int i=1;i<num;i++) {
            if(stats.at<int>(i, CC_STAT_AREA) < 800)
                mask.setTo(0, labels == i);
        }

        cv::GaussianBlur(mask, mask, cv::Size(5,5), 0);
        cv::threshold(mask, mask, 128, 255, THRESH_BINARY);

        cv::Mat maskF;
        mask.convertTo(maskF, CV_32FC1, 1.0/255.0);

        cv::Mat bgFinal;
        if(useColorBg)
            bgFinal = cv::Mat(baseResized.size(), CV_8UC3, Scalar(bgColor.blue(), bgColor.green(), bgColor.red()));
        else if(useImageBg && !bg.empty())
            cv::resize(bg, bgFinal, baseResized.size());
        else
            bgFinal = cv::Mat(baseResized.size(), CV_8UC3, Scalar(0,0,0));

        cv::Mat fgF, bgF, resultF;
        baseResized.convertTo(fgF, CV_32FC3);
        bgFinal.convertTo(bgF, CV_32FC3);

        cv::Mat maskF3;
        cv::cvtColor(maskF, maskF3, COLOR_GRAY2BGR);
        cv::multiply(fgF, maskF3, fgF);
        cv::multiply(bgF, Scalar(1,1,1) - maskF3, bgF);
        cv::add(fgF, bgF, resultF);

        resultF.convertTo(result, CV_8UC3);
        showMat(result);
    }

    void showMat(const cv::Mat &mat) {
        cv::Mat rgb;
        cv::cvtColor(mat, rgb, cv::COLOR_BGR2RGB);
        QImage qimg((uchar*)rgb.data, rgb.cols, rgb.rows, rgb.step, QImage::Format_RGB888);
        imageLabel->setPixmap(QPixmap::fromImage(qimg).scaled(imageLabel->size(), Qt::KeepAspectRatio, Qt::SmoothTransformation));
    }
};

int main(int argc, char *argv[]) {
    QApplication app(argc, argv);
    MainWindow w;
    w.setWindowTitle("Schimbare fundal imagine");
    w.show();
    return app.exec();
}
