#include <QApplication>
#include <QWidget>
#include <QPushButton>
#include <QRadioButton>
#include <QLabel>
#include <QFileDialog>
#include <QVBoxLayout>
#include <QGroupBox>
#include <QMessageBox>
#include <QImage>
#include <QImageReader>
#include <QFileInfo>
#include <QDir>
#include <QString>
#include <filesystem>

namespace fs = std::filesystem;

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);

    QWidget window;
    window.setWindowTitle("Oglindire Imagini");
    window.resize(400, 300);

    QString sourcePath;
    QString destinationPath;

    QPushButton *btnSource = new QPushButton("Selectează folder sursă");
    QPushButton *btnDestination = new QPushButton("Selectează folder destinație");
    QLabel *lblSource = new QLabel("Nicio cale selectată");
    QLabel *lblDestination = new QLabel("Nicio cale selectată");

    QRadioButton *radioHorizontal = new QRadioButton("Oglindire orizontală");
    QRadioButton *radioVertical = new QRadioButton("Oglindire verticală");
    QRadioButton *radioBoth = new QRadioButton("Oglindire orizontală și verticală");

    QPushButton *btnExecute = new QPushButton("Execută");

    QGroupBox *group = new QGroupBox("Opțiuni oglindire");
    QVBoxLayout *radioLayout = new QVBoxLayout;
    radioLayout->addWidget(radioHorizontal);
    radioLayout->addWidget(radioVertical);
    radioLayout->addWidget(radioBoth);
    group->setLayout(radioLayout);

    QVBoxLayout *mainLayout = new QVBoxLayout;
    mainLayout->addWidget(btnSource);
    mainLayout->addWidget(lblSource);
    mainLayout->addWidget(btnDestination);
    mainLayout->addWidget(lblDestination);
    mainLayout->addWidget(group);
    mainLayout->addWidget(btnExecute);

    window.setLayout(mainLayout);

    QObject::connect(btnSource, &QPushButton::clicked, [&]() {
        QString dir = QFileDialog::getExistingDirectory(nullptr, "Selectează folder sursă");
        if (!dir.isEmpty()) {
            sourcePath = dir;
            lblSource->setText("Sursă: " + sourcePath);
        }
    });

    QObject::connect(btnDestination, &QPushButton::clicked, [&]() {
        QString dir = QFileDialog::getExistingDirectory(nullptr, "Selectează folder destinație");
        if (!dir.isEmpty()) {
            destinationPath = dir;
            lblDestination->setText("Destinație: " + destinationPath);
        }
    });

    QObject::connect(btnExecute, &QPushButton::clicked, [&]() {
        if (sourcePath.isEmpty() || destinationPath.isEmpty()) {
            QMessageBox::warning(nullptr, "Atenție", "Selectează ambele foldere.");
            return;
        }

        int mode = 0;
        if (radioHorizontal->isChecked()) mode = 1;
        else if (radioVertical->isChecked()) mode = 2;
        else if (radioBoth->isChecked()) mode = 3;
        else {
            QMessageBox::warning(nullptr, "Atenție", "Selectează o opțiune de oglindire.");
            return;
        }

        const QStringList allowedExt = {"jpg","jpeg","png","bmp","gif","tif","tiff"};

        for (const auto &entry : fs::directory_iterator(sourcePath.toStdString())) {
            if (!entry.is_regular_file()) continue;

            QString filePath = QString::fromStdString(entry.path().string());
            QString ext = QFileInfo(filePath).suffix().toLower();
            if (!allowedExt.contains(ext)) continue;

            QImageReader reader(filePath);
            reader.setAutoTransform(true);
            QImage img = reader.read();
            if (img.isNull()) continue;

            QImage mirrored;
            if (mode == 1) {
                mirrored = img.flipped(Qt::Horizontal);
            } else if (mode == 2) {
                mirrored = img.flipped(Qt::Vertical);
            } else {
                QTransform transform;
                transform.rotate(180);
                mirrored = img.transformed(transform);
            }

            QString fileName = QFileInfo(filePath).fileName();
            QDir destDir(destinationPath);
            QString savePath = destDir.filePath(fileName);

            mirrored.save(savePath);
        }

        QMessageBox::information(nullptr, "Gata", "Oglindirea a fost finalizată.");
    });

    window.show();
    return a.exec();
}
