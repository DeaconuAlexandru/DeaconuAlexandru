CUM SA FOLOSESTI APLICATIA
Pasul 1:
In proiect pro bagi aceste linii de cod ca sa iti mearga aplicatia:
QT = core

CONFIG += c++17 cmdline

# You can make your code fail to compile if it uses deprecated APIs.
# In order to do so, uncomment the following line.
#DEFINES += QT_DISABLE_DEPRECATED_BEFORE=0x060000    # disables all the APIs deprecated before Qt 6.0.0

SOURCES += \
        main.cpp

# Default rules for deployment.
qnx: target.path = /tmp/$${TARGET}/bin
else: unix:!android: target.path = /opt/$${TARGET}/bin
!isEmpty(target.path): INSTALLS += target
INCLUDEPATH += C:\Users\deaco\OneDrive\Desktop\OpenCV\build\include \


LIBS += -LC:\Users\deaco\OneDrive\Desktop\OpenCV\build\x64\vc16\lib \
-lopencv_world4110 \
-lopencv_world4110d
QT += core gui widgets
CONFIG += c++17 console
TEMPLATE = app
SOURCES += main.cpp
Pasul 2:
Sa ai qt versiunea 3.9.3 instalata este un beneficiu
Pasul 3:Fa-ti 2 fisiere unul de input in care iti pui pozele si unul de output pe care sa il lasi gol si sa lasi aplicatia sa isi faca treaba.
Pasul 4: Bucura-te de aplicatie.