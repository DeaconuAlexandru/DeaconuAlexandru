#include <QApplication>       // Biblioteca pentru aplicatia Qt
#include <QMainWindow>        // Clasa pentru fereastra principala
#include <QPushButton>        // Clasa pentru butoane
#include <QVBoxLayout>        // Layout vertical
#include <QLabel>             // Afisare imagini/text
#include <QFileDialog>        // Dialog pentru selectarea fisierelor
#include <QColorDialog>       // Dialog pentru selectarea culorii
#include <QMouseEvent>        // Evenimente mouse
#include <QPainter>           // Desenare pe widget
#include <QStatusBar>         // Bara de status
#include <opencv2/opencv.hpp> // Biblioteca OpenCV
#include <functional>         // Pentru std::function

using namespace cv;           // Folosim spatiul de nume OpenCV

// QLabel custom pentru selectarea ROI (Regiune de Interes)
class ImageLabel : public QLabel {
public:
    ImageLabel(QWidget *parent = nullptr) : QLabel(parent), dragging(false) {
        setScaledContents(true);  // Imaginea se scaleaza automat in label
    }

    void setImage(const QImage &img) { // Seteaza imaginea afisata
        currentImage = img;
        setPixmap(QPixmap::fromImage(img));
    }

    QRect getROI() const { return roiRect; } // Returneaza ROI selectat

    std::function<void(QRect)> onRoiSelected; // Callback la selectarea ROI

protected:
    void mousePressEvent(QMouseEvent *event) override { // Cand apasam click stanga
        if (event->button() == Qt::LeftButton) {
            dragging = true;             // Activam trasarea
            startPoint = event->pos();   // Retinem punctul de start
            endPoint = startPoint;       // Initializam punctul final
        }
    }

    void mouseMoveEvent(QMouseEvent *event) override { // Cand miscam mouse-ul
        if (dragging) {
            endPoint = event->pos();    // Actualizam punctul final
            update();                   // Reafisam rectangle-ul
        }
    }

    void mouseReleaseEvent(QMouseEvent *event) override { // Cand eliberam click-ul
        if (event->button() == Qt::LeftButton && dragging) {
            dragging = false;                 // Oprim trasarea
            endPoint = event->pos();          // Punct final ROI
            roiRect = QRect(startPoint, endPoint).normalized(); // Normalizam rect
            if (onRoiSelected) onRoiSelected(roiRect);         // Apelam callback
            update();                           // Reafisam
        }
    }

    void paintEvent(QPaintEvent *event) override { // Desenare ROI in timp real
        QLabel::paintEvent(event);
        if (dragging) {
            QPainter painter(this);               // Obiect pentru desen
            painter.setPen(QPen(Qt::green, 2));    // Culoare si grosime contur
            painter.drawRect(QRect(startPoint, endPoint)); // Desenam dreptunghi
        }
    }

private:
    bool dragging;        // Flag daca trasam
    QPoint startPoint, endPoint; // Punctele ROI
    QRect roiRect;        // ROI selectat
    QImage currentImage;  // Imagine curenta
};

// Fereastra principala a aplicatiei
class MainWindow : public QMainWindow {
public:
    MainWindow() {
        resize(1000, 700);                      // Dimensiune fereastra
        QWidget *central = new QWidget(this);   // Widget central
        QVBoxLayout *layout = new QVBoxLayout(central); // Layout vertical

        // Butoane
        QPushButton *loadBtn = new QPushButton("Incarca imagine");
        QPushButton *segmentBtn = new QPushButton("Segmentare ROI");
        QPushButton *colorBtn = new QPushButton("Alege culoare fundal");
        QPushButton *saveBtn = new QPushButton("Salveaza rezultat");

        imageLabel = new ImageLabel(this);       // Label pentru afisarea imaginii
        imageLabel->setAlignment(Qt::AlignCenter);

        // Adaugam widget-urile in layout
        layout->addWidget(loadBtn);
        layout->addWidget(segmentBtn);
        layout->addWidget(colorBtn);
        layout->addWidget(saveBtn);
        layout->addWidget(imageLabel);
        setCentralWidget(central); // Setam widget-ul central

        // Conectam actiunile butoanelor la functii
        connect(loadBtn, &QPushButton::clicked, [=]() { loadImage(); });
        connect(segmentBtn, &QPushButton::clicked, [=]() { segmentROI(); });
        connect(colorBtn, &QPushButton::clicked, [=]() { chooseColor(); applyBackground(); });
        connect(saveBtn, &QPushButton::clicked, [=]() { saveResult(); });

        imageLabel->onRoiSelected = [&](QRect rect) { roi = rect; }; // ROI selectat

        bgColor = Qt::magenta; // Culoare fundal initiala
        statusBar()->showMessage("Alege o imagine pentru procesare"); // Mesaj initial
    }

private:
    void loadImage() {
        // Deschidem dialog pentru selectare fisier imagine
        QString path = QFileDialog::getOpenFileName(this, "Alege imagine", "", "Imagini (*.jpg *.png *.jpeg)");
        if (path.isEmpty()) return;

        original = imread(path.toStdString());   // Citim imaginea cu OpenCV
        if (original.empty()) {                  // Daca nu s-a incarcat
            statusBar()->showMessage("Eroare la incarcarea imaginii");
            return;
        }

        result = original.clone();               // Clonam pentru rezultat
        binMask.release();                       // Stergem masca veche
        imageLabel->setImage(matToQImage(original)); // Afisam imaginea in GUI
        statusBar()->showMessage("Imagine incarcata");
    }

    void chooseColor() {
        // Dialog pentru alegerea culorii fundalului
        QColor c = QColorDialog::getColor(bgColor, this, "Alege culoare fundal");
        if (c.isValid()) {
            bgColor = c;                        // Salvam culoarea aleasa
            statusBar()->showMessage("Culoare fundal actualizata");
        }
    }

    void segmentROI() {
        // Verificam daca imaginea si ROI-ul sunt valide
        if (original.empty() || roi.width() <= 0 || roi.height() <= 0) {
            statusBar()->showMessage("Incarca imaginea si selecteaza ROI valid");
            return;
        }

        // Definim ROI pentru OpenCV
        Rect cvRect(roi.x(), roi.y(), roi.width(), roi.height());

        // Initializam masca GrabCut (0 = fundal, 3 = posibil obiect)
        Mat mask(original.size(), CV_8UC1, Scalar(GC_BGD));
        mask(cvRect).setTo(Scalar(GC_PR_FGD));

        Mat bgModel, fgModel; // Modele interne GrabCut
        grabCut(original, mask, cvRect, bgModel, fgModel, 5, GC_INIT_WITH_RECT); // Aplicam GrabCut

        // Convertim masca la binar (255 = obiect, 0 = fundal)
        binMask = (mask == GC_FGD) | (mask == GC_PR_FGD);

        // Curatare artefacte mici cu morfologie
        Mat kernel = getStructuringElement(MORPH_ELLIPSE, Size(3,3));
        morphologyEx(binMask, binMask, MORPH_OPEN, kernel);  // elimina puncte izolate
        morphologyEx(binMask, binMask, MORPH_CLOSE, kernel); // inchide goluri mici

        applyBackground();  // Aplicam fundalul selectat
        statusBar()->showMessage("Segmentare completa si fundal aplicat");
    }

    void applyBackground() {
        if (original.empty() || binMask.empty()) return;

        result = original.clone(); // Clonam imaginea initiala

        // Cream imagine cu fundal uniform
        Mat bg(result.size(), result.type(), Scalar(bgColor.blue(), bgColor.green(), bgColor.red()));

        // Copiem fundalul peste zonele negre din masca (vectorizat)
        bg.copyTo(result, ~binMask);

        imageLabel->setImage(matToQImage(result)); // Actualizam GUI imediat
    }

    void saveResult() {
        if (result.empty()) return;

        // Dialog pentru salvare fisier
        QString path = QFileDialog::getSaveFileName(this, "Salveaza imagine", "rezultat.jpg", "Imagini (*.jpg *.png)");
        if (path.isEmpty()) return;

        imwrite(path.toStdString(), result); // Salvam imaginea
        statusBar()->showMessage("Imagine salvata");
    }

    // Convertim Mat OpenCV la QImage pentru afisare
    QImage matToQImage(const Mat &mat) {
        Mat rgb;
        cvtColor(mat, rgb, COLOR_BGR2RGB); // Convertim BGR -> RGB
        return QImage((uchar*)rgb.data, rgb.cols, rgb.rows, rgb.step, QImage::Format_RGB888).copy();
    }

    ImageLabel *imageLabel; // Label pentru imagine
    Mat original, result, binMask; // Imagine originala, rezultat, masca binara
    QRect roi;               // ROI selectat
    QColor bgColor;          // Culoare fundal
};

int main(int argc, char *argv[]) {
    QApplication app(argc, argv); // Initializam aplicatia Qt
    MainWindow window;             // Cream fereastra principala
    window.show();                 // Afisam fereastra
    return app.exec();             // Pornim bucla de evenimente
}

